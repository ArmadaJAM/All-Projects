/* Exercise 1: Writing Your First Callback Function */
function calculate(num1, num2, operation) {
    return operation(num1, num2);
}

function add(a, b) {
    return a + b;
}

function subtract(a, b) {
    return a - b;
}

function multiply(a, b) {
    return a * b;
}

function divide(a, b) {
    return a / b;
}

// Testing the calculate function
console.log(calculate(5, 3, add));     
console.log(calculate(5, 3, subtract));  
console.log(calculate(5, 3, divide));     

/* Exercise 2: Using Callbacks with setTimeout */
function delayedMessage(message, delay, beforeCallback, afterCallback) {
    beforeCallback();
    setTimeout(() => {
        afterCallback(message);
    }, delay);
}

delayedMessage("Hello, world!", 2000, 
    function() {
        console.log("Starting delay...");
    }, 
    function(msg) {
        console.log(msg);
    }
);

/* Exercise 3: Looping with Callbacks */
function repeatTask(times, callback) {
    for (let i = 0; i < times; i++) {
        if (callback(i) === false) {
            break;
        }
    }
}

repeatTask(5, function(index) {
    if (index === 3) {
        return false; 
    }
    console.log("Iteration:", index);
});

